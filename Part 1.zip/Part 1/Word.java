package csci6461;

import java.util.BitSet;

public class Word extends BitSet {
	
	private static final long serialVersionUID = 1L;

	public Word() {
		super(16);
	}
}
